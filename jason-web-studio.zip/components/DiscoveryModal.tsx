
import React, { useState, useEffect, useRef } from 'react';
import { getDiscoveryResponse } from '../services/geminiService.ts';

interface Message {
  role: 'user' | 'model';
  text: string;
}

const DiscoveryModal: React.FC<{ isOpen: boolean; onClose: () => void; onBookRealCall: () => void }> = ({ isOpen, onClose, onBookRealCall }) => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: "Welcome to Jason Web Studio. I've been expecting you. Before we talk strategy, tell me: what's the name of your property and where in the world is it located?" }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  if (!isOpen) return null;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isTyping) return;

    const userMessage = input.trim();
    setInput('');
    const newMessages: Message[] = [...messages, { role: 'user', text: userMessage }];
    setMessages(newMessages);
    setIsTyping(true);

    const history = newMessages.map(m => ({
      role: m.role,
      parts: [{ text: m.text }]
    }));

    const response = await getDiscoveryResponse(history);
    setMessages(prev => [...prev, { role: 'model', text: response || '' }]);
    setIsTyping(false);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8 animate-in fade-in duration-300">
      <div className="absolute inset-0 bg-charcoal/95 backdrop-blur-xl" onClick={onClose}></div>
      
      <div className="relative w-full max-w-4xl bg-cream h-[80vh] md:h-[700px] shadow-2xl overflow-hidden flex flex-col border border-accent/20">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-charcoal/5 bg-white">
          <div className="flex items-center gap-4">
            <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
            <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-charcoal">Fictional Discovery Session / AI</span>
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={onBookRealCall}
              className="hidden sm:block text-[9px] font-bold uppercase tracking-[0.2em] bg-accent text-charcoal px-4 py-2 hover:bg-charcoal hover:text-cream transition-all"
            >
              Book Real Call
            </button>
            <button onClick={onClose} className="text-2xl text-charcoal/40 hover:text-charcoal transition-colors">&times;</button>
          </div>
        </div>

        {/* Call Info Overlay */}
        <div className="bg-charcoal text-cream px-8 py-4 flex justify-between items-center">
          <div className="flex items-center gap-6">
            <div className="flex -space-x-2">
              <div className="w-8 h-8 rounded-full bg-accent border-2 border-charcoal flex items-center justify-center text-[10px] font-bold text-charcoal">J</div>
              <div className="w-8 h-8 rounded-full bg-cream/20 border-2 border-charcoal flex items-center justify-center text-[10px] font-bold italic">You</div>
            </div>
            <div className="text-[10px] uppercase tracking-widest font-bold">Jason AI + You</div>
          </div>
          <div className="hidden sm:block text-[10px] text-cream/40 uppercase tracking-widest">Encrypted Simulation Line</div>
        </div>

        {/* Chat Area */}
        <div ref={scrollRef} className="flex-grow overflow-y-auto p-8 space-y-8 scroll-smooth">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 duration-500`}>
              <div className={`max-w-[80%] ${m.role === 'user' ? 'bg-accent text-charcoal p-6' : 'bg-white border border-charcoal/5 p-6'} shadow-sm`}>
                <div className="text-[10px] uppercase tracking-widest font-bold mb-2 opacity-40">{m.role === 'model' ? 'Jason AI' : 'Client'}</div>
                <p className="text-lg font-light leading-relaxed">{m.text}</p>
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex justify-start animate-pulse">
              <div className="bg-white border border-charcoal/5 p-6 shadow-sm">
                <div className="flex gap-1">
                  <div className="w-1 h-1 bg-accent rounded-full"></div>
                  <div className="w-1 h-1 bg-accent rounded-full"></div>
                  <div className="w-1 h-1 bg-accent rounded-full"></div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <form onSubmit={handleSend} className="p-8 bg-white border-t border-charcoal/5">
          <div className="flex gap-4">
            <input 
              autoFocus
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your response..."
              className="flex-grow bg-cream/50 border border-charcoal/5 px-6 py-4 focus:outline-none focus:border-accent transition-colors text-lg font-light"
            />
            <button 
              type="submit"
              disabled={isTyping}
              className="bg-charcoal text-cream px-8 py-4 font-bold uppercase tracking-widest text-[10px] hover:bg-accent transition-all disabled:opacity-50"
            >
              Send
            </button>
          </div>
          <div className="mt-4 flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-[9px] text-charcoal/30 uppercase tracking-widest">Note: This is a fictional simulation of a discovery call.</p>
            <button 
              type="button"
              onClick={onBookRealCall}
              className="text-[9px] font-bold text-accent uppercase tracking-widest hover:text-charcoal transition-colors border-b border-accent"
            >
              Skip to Real Booking on Cal.com
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default DiscoveryModal;
