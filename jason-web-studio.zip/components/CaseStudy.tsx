
import React from 'react';

const CaseStudy: React.FC = () => {
  return (
    <section id="case-study" className="py-32 px-6 md:px-12 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="mb-24 text-center max-w-4xl mx-auto">
          <span className="text-xs font-bold uppercase tracking-[0.4em] text-accent mb-6 block">The Proof</span>
          <h2 className="text-4xl md:text-6xl mb-8 tracking-tight">How One Villa Went From OTA Reliance to Direct Booking Dominance</h2>
          <p className="text-xl text-charcoal/50 font-light">This isn't theory. This is what happened when web design met hospitality knowledge.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-0 border border-charcoal/5 shadow-2xl">
          <div className="bg-cream p-12 lg:p-16 border-r border-charcoal/5">
            <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-charcoal/30 mb-8 block">01 / Before</span>
            <h3 className="text-3xl mb-8">The Situation</h3>
            <ul className="space-y-6 text-charcoal/70 font-light">
              <li className="flex items-start gap-4">
                <span className="mt-2 w-1.5 h-1.5 bg-charcoal/20 rounded-full shrink-0"></span>
                80% bookings through Booking.com and Airbnb
              </li>
              <li className="flex items-start gap-4">
                <span className="mt-2 w-1.5 h-1.5 bg-charcoal/20 rounded-full shrink-0"></span>
                Paying €45,000+ annually in commissions
              </li>
              <li className="flex items-start gap-4">
                <span className="mt-2 w-1.5 h-1.5 bg-charcoal/20 rounded-full shrink-0"></span>
                Zero control over guest relationships
              </li>
            </ul>
          </div>

          <div className="bg-charcoal p-12 lg:p-16 relative overflow-hidden">
            <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-accent mb-8 block">02 / The Framework</span>
            <h3 className="text-3xl text-cream mb-8">The Strategy</h3>
            <ul className="space-y-6 text-cream/70 font-light relative z-10">
              <li className="flex items-start gap-4">
                <span className="mt-2 w-1.5 h-1.5 bg-accent rounded-full shrink-0"></span>
                Conversion-first architectural redesign
              </li>
              <li className="flex items-start gap-4">
                <span className="mt-2 w-1.5 h-1.5 bg-accent rounded-full shrink-0"></span>
                High-intent SEO targeting global travelers
              </li>
              <li className="flex items-start gap-4">
                <span className="mt-2 w-1.5 h-1.5 bg-accent rounded-full shrink-0"></span>
                Seamless, frictionless booking engine
              </li>
            </ul>
            <div className="absolute bottom-[-20%] right-[-10%] w-64 h-64 bg-accent/10 blur-3xl rounded-full"></div>
          </div>

          <div className="bg-white p-12 lg:p-16">
            <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-green-600 mb-8 block">03 / The Results</span>
            <h3 className="text-3xl mb-8">The Impact</h3>
            <ul className="space-y-6 text-charcoal/70 font-light">
              <li className="flex items-start gap-4">
                <span className="mt-2 w-1.5 h-1.5 bg-accent rounded-full shrink-0"></span>
                <span className="text-charcoal font-bold">Revenue tripled</span> in 18 months
              </li>
              <li className="flex items-start gap-4">
                <span className="mt-2 w-1.5 h-1.5 bg-accent rounded-full shrink-0"></span>
                <span className="text-charcoal font-bold">70% Direct bookings</span> achieved
              </li>
              <li className="flex items-start gap-4">
                <span className="mt-2 w-1.5 h-1.5 bg-accent rounded-full shrink-0"></span>
                <span className="text-charcoal font-bold">€78,000+ saved</span> in OTA fees
              </li>
            </ul>
          </div>
        </div>

        <div className="max-w-4xl mx-auto mt-24 text-center">
          <p className="text-2xl md:text-3xl font-light italic text-charcoal/80 mb-8">
            "Growing up, I watched my family lose thousands to booking platforms every season. I rebuilt our site, and everything changed. Now I do it for you."
          </p>
          <div className="font-bold text-xs uppercase tracking-[0.3em] text-accent">— Jason, Founder</div>
        </div>
      </div>
    </section>
  );
};

export default CaseStudy;
