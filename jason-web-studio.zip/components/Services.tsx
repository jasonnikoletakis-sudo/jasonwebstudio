import React from 'react';

const Services: React.FC = () => {
  return (
    <section id="services" className="py-40 px-6 md:px-12 bg-charcoal text-cream overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-20 items-start mb-32">
          <div className="lg:col-span-5">
            <span className="text-xs font-bold uppercase tracking-[0.4em] text-accent mb-6 block">Our Approach</span>
            <h2 className="text-5xl md:text-7xl mb-8 tracking-tighter leading-tight">Web Design & SEO for Hospitality</h2>
            <p className="text-xl text-cream/40 font-light max-w-lg leading-relaxed">Two things drive direct bookings: a website that converts and visibility when guests are searching. Everything else is just noise.</p>
          </div>
          
          <div className="lg:col-span-7 grid grid-cols-1 md:grid-cols-2 gap-px bg-white/10 border border-white/10">
            <div className="bg-charcoal p-12 hover:bg-white/[0.02] transition-colors group">
              <div className="w-10 h-10 mb-10 bg-accent text-charcoal flex items-center justify-center font-bold text-xs tracking-widest group-hover:scale-110 transition-transform">01</div>
              <h3 className="text-2xl mb-4 group-hover:text-accent transition-colors">Strategic Web Design</h3>
              <p className="text-cream/40 mb-10 font-light text-sm leading-relaxed">Every element designed to build trust, showcase your unique experience, and make booking effortless.</p>
              <ul className="space-y-4 text-xs font-bold tracking-widest text-cream/60">
                <li className="flex items-center gap-3"><span className="w-1 h-1 bg-accent rounded-full"></span> CUSTOM ARCHITECTURE</li>
                <li className="flex items-center gap-3"><span className="w-1 h-1 bg-accent rounded-full"></span> PERFORMANCE DRIVEN</li>
                <li className="flex items-center gap-3"><span className="w-1 h-1 bg-accent rounded-full"></span> BOOKING INTEGRATION</li>
              </ul>
            </div>
            
            <div className="bg-charcoal p-12 hover:bg-white/[0.02] transition-colors group">
              <div className="w-10 h-10 mb-10 border border-accent text-accent flex items-center justify-center font-bold text-xs tracking-widest group-hover:bg-accent group-hover:text-charcoal transition-all">02</div>
              <h3 className="text-2xl mb-4 group-hover:text-accent transition-colors">Hospitality SEO</h3>
              <p className="text-cream/40 mb-10 font-light text-sm leading-relaxed">Target high-intent searches that drive bookings. Consistent, measurable visibility where it actually matters.</p>
              <ul className="space-y-4 text-xs font-bold tracking-widest text-cream/60">
                <li className="flex items-center gap-3"><span className="w-1 h-1 bg-accent rounded-full"></span> KEYWORD DOMINANCE</li>
                <li className="flex items-center gap-3"><span className="w-1 h-1 bg-accent rounded-full"></span> ON-PAGE OPTIMIZATION</li>
                <li className="flex items-center gap-3"><span className="w-1 h-1 bg-accent rounded-full"></span> PERFORMANCE DATA</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="relative p-12 md:p-24 bg-cream text-charcoal overflow-hidden group">
          <div className="relative z-10 max-w-3xl">
            <h3 className="text-4xl md:text-5xl mb-8 tracking-tight">The Complete System</h3>
            <p className="text-xl mb-12 text-charcoal/60 font-light leading-relaxed">
              Design and SEO aren't separate projects—they're two parts of one strategy. The Framework combines both to create a system that attracts the right guests and converts them into direct bookings.
            </p>
          </div>
          <div className="absolute right-[-5%] bottom-[-10%] w-[50%] h-[110%] bg-accent/5 -rotate-6 group-hover:rotate-0 transition-transform duration-1000"></div>
        </div>
      </div>
    </section>
  );
};

export default Services;