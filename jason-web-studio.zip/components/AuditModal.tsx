
import React, { useState } from 'react';
import { getPropertyAudit } from '../services/geminiService.ts';

const AuditModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const [propertyName, setPropertyName] = useState('');
  const [location, setLocation] = useState('');
  const [loading, setLoading] = useState(false);
  const [auditResult, setAuditResult] = useState<any>(null);

  if (!isOpen) return null;

  const handleAudit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!propertyName || !location) return;
    setLoading(true);
    const result = await getPropertyAudit(propertyName, location);
    setAuditResult(result);
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 md:p-8 animate-in fade-in duration-300">
      <div className="absolute inset-0 bg-charcoal/95 backdrop-blur-xl" onClick={onClose}></div>
      
      <div className="relative w-full max-w-4xl bg-cream h-[85vh] shadow-2xl overflow-hidden flex flex-col border border-accent/20">
        <div className="flex items-center justify-between p-6 border-b border-charcoal/5 bg-white">
          <div className="flex items-center gap-4">
            <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-accent">Real-Time Market Audit / AI powered</span>
          </div>
          <button onClick={onClose} className="text-2xl text-charcoal/40 hover:text-charcoal transition-colors">&times;</button>
        </div>

        <div className="flex-grow overflow-y-auto p-8 md:p-12">
          {!auditResult ? (
            <div className="max-w-xl mx-auto py-12">
              <h2 className="text-4xl mb-8 tracking-tighter text-charcoal text-center">Get Your Free Property Audit</h2>
              <p className="text-charcoal/50 font-light text-center mb-12 italic">Jason's AI will scan your market presence and provide 3 immediate improvements.</p>
              
              <form onSubmit={handleAudit} className="space-y-8">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-charcoal/40 mb-4">Property Name</label>
                  <input 
                    required
                    value={propertyName}
                    onChange={(e) => setPropertyName(e.target.value)}
                    placeholder="e.g. Villa Maritima"
                    className="w-full bg-white border-b border-charcoal/10 px-0 py-4 text-2xl font-light focus:outline-none focus:border-accent transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-[0.2em] text-charcoal/40 mb-4">Location</label>
                  <input 
                    required
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="e.g. Amalfi Coast, Italy"
                    className="w-full bg-white border-b border-charcoal/10 px-0 py-4 text-2xl font-light focus:outline-none focus:border-accent transition-colors"
                  />
                </div>
                <button 
                  disabled={loading}
                  className="w-full py-6 bg-charcoal text-cream text-[10px] font-bold uppercase tracking-[0.3em] hover:bg-accent disabled:opacity-50 transition-all shadow-xl"
                >
                  {loading ? 'Analyzing Digital Presence...' : 'Run Audit'}
                </button>
              </form>
            </div>
          ) : (
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
              <div className="grid grid-cols-1 md:grid-cols-12 gap-12">
                <div className="md:col-span-4">
                  <div className="bg-charcoal text-cream p-10 text-center border-b-4 border-accent">
                    <div className="text-[10px] uppercase tracking-widest opacity-40 mb-2">Digital Health Score</div>
                    <div className="text-7xl font-bold tracking-tighter">{auditResult.overallScore}</div>
                    <div className="mt-4 text-[10px] font-bold text-accent uppercase tracking-widest">/ 100 Potential</div>
                  </div>
                </div>
                <div className="md:col-span-8">
                  <h3 className="text-3xl mb-6">Market Analysis</h3>
                  <p className="text-charcoal/70 font-light leading-relaxed mb-8">{auditResult.marketAnalysis}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mt-16 border-t border-charcoal/5 pt-16">
                <div>
                  <h4 className="text-[10px] font-bold uppercase tracking-[0.3em] text-accent mb-6">Top Local Competitors</h4>
                  <ul className="space-y-4">
                    {auditResult.competitors.map((comp: string, i: number) => (
                      <li key={i} className="flex items-center gap-4 text-charcoal/70 font-light">
                        <span className="w-1.5 h-1.5 bg-accent/30 rounded-full"></span> {comp}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h4 className="text-[10px] font-bold uppercase tracking-[0.3em] text-accent mb-6">Recommendations</h4>
                  <div className="space-y-4">
                    {auditResult.recommendations.map((rec: string, i: number) => (
                      <div key={i} className="p-4 bg-white border border-charcoal/5 text-sm font-light italic">
                        "{rec}"
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="mt-20 text-center">
                <p className="text-charcoal/40 text-sm mb-8 font-light italic">This audit provides a surface-level look. For a deep strategy, let's talk.</p>
                <button 
                  onClick={() => setAuditResult(null)} 
                  className="text-[10px] font-bold uppercase tracking-widest text-charcoal/30 hover:text-charcoal transition-colors underline underline-offset-8"
                >
                  New Audit
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AuditModal;
