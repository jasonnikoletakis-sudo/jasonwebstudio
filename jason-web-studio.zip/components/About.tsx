import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-40 px-6 md:px-12 bg-cream">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row gap-24 items-center">
          <div className="w-full lg:w-1/2">
            <div className="relative">
              <div className="absolute inset-0 border border-accent/20 translate-x-4 translate-y-4 -z-10"></div>
              <img 
                src="https://picsum.photos/seed/hospitality/800/1000" 
                alt="Jason Nikoletakis, Founder" 
                className="w-full h-auto grayscale hover:grayscale-0 transition-all duration-1000 shadow-2xl saturate-[0.8]"
              />
              <div className="absolute -bottom-8 -right-8 bg-charcoal p-12 text-cream shadow-2xl">
                <div className="text-5xl font-bold mb-2 text-accent">18</div>
                <div className="text-[10px] uppercase tracking-[0.3em] font-bold text-cream/40">Months to Triple Revenue</div>
              </div>
            </div>
          </div>
          
          <div className="w-full lg:w-1/2">
            <span className="text-xs font-bold uppercase tracking-[0.4em] text-accent mb-6 block">Born Into Hospitality</span>
            <h2 className="text-5xl md:text-7xl mb-10 tracking-tighter leading-[1.1]">I didn't choose hotels. <br /><span className="text-accent italic font-light">Hotels chose me.</span></h2>
            <div className="space-y-8 text-lg text-charcoal/70 font-light leading-relaxed">
              <p>
                My name is <span className="text-charcoal font-bold">Jason Nikoletakis</span>. I grew up in the family business—a boutique villa where I learned that hospitality isn't just about beautiful properties. It's about sustainable revenue, guest relationships, and independence.
              </p>
              <p>
                After years of watching commissions drain profits, I combined my web design skills with deep hospitality knowledge to solve the problem.
              </p>
              <p className="text-charcoal font-medium border-l-2 border-accent pl-8">
                This isn't a web design agency that happens to work with hotels. This is a hospitality revenue strategy that happens to use web design.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mt-20 border-t border-charcoal/10 pt-16">
              <div>
                <h4 className="font-bold text-[10px] uppercase tracking-[0.3em] text-accent mb-4">Deep Industry Knowledge</h4>
                <p className="text-sm text-charcoal/50 leading-relaxed">I understand occupancy rates, shoulder seasons, and the real cost of OTA dependency.</p>
              </div>
              <div>
                <h4 className="font-bold text-[10px] uppercase tracking-[0.3em] text-accent mb-4">Proven Methodology</h4>
                <p className="text-sm text-charcoal/50 leading-relaxed">The framework I use tripled my family's villa revenue. It's tested and refined.</p>
              </div>
              <div>
                <h4 className="font-bold text-[10px] uppercase tracking-[0.3em] text-accent mb-4">Pure Revenue Focus</h4>
                <p className="text-sm text-charcoal/50 leading-relaxed">Every design decision is made through one filter: does this increase direct bookings?</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;