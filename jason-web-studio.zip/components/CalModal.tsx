
import React, { useEffect } from 'react';
import { getCalConfig } from '../services/calService.ts';

const CalModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const config = getCalConfig();
  const calLink = `${config.username}/${config.eventSlug}`;

  useEffect(() => {
    if (isOpen && (window as any).Cal) {
      (window as any).Cal("modal", {
        calLink: calLink,
        config: {"theme":"light"}
      });
    }
  }, [isOpen, calLink]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 md:p-8 animate-in fade-in duration-300">
      <div className="absolute inset-0 bg-charcoal/98 backdrop-blur-2xl" onClick={onClose}></div>
      
      <div className="relative w-full max-w-5xl bg-white h-[90vh] shadow-2xl overflow-hidden flex flex-col border border-accent/20">
        <div className="flex items-center justify-between p-6 border-b border-charcoal/5 bg-white">
          <div className="flex items-center gap-4">
            <div className="w-2 h-2 bg-accent rounded-full"></div>
            <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-charcoal">Official Booking Portal / Cal.com</span>
          </div>
          <button onClick={onClose} className="text-2xl text-charcoal/40 hover:text-charcoal transition-colors">&times;</button>
        </div>

        <div className="flex-grow bg-cream/20 relative">
          <iframe 
            src={`https://cal.com/${calLink}?embed=true`} 
            title="Schedule a discovery call"
            className="w-full h-full border-none"
          />
        </div>

        <div className="p-4 bg-charcoal text-[9px] text-cream/40 text-center uppercase tracking-[0.2em] font-bold">
          Linked Account: {config.username} • Secure Scheduling
        </div>
      </div>
    </div>
  );
};

export default CalModal;
