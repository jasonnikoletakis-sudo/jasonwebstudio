
import React, { useState } from 'react';

const FAQItem: React.FC<{ question: string; answer: string }> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="border-b border-charcoal/10 py-8">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center text-left"
      >
        <span className="text-xl md:text-2xl font-medium pr-8">{question}</span>
        <span className={`text-3xl transition-transform duration-300 ${isOpen ? 'rotate-45' : ''}`}>+</span>
      </button>
      <div className={`overflow-hidden transition-all duration-500 ${isOpen ? 'max-h-[500px] mt-6 opacity-100' : 'max-h-0 opacity-0'}`}>
        <p className="text-charcoal/60 text-lg font-light leading-relaxed max-w-4xl">{answer}</p>
      </div>
    </div>
  );
};

const FAQ: React.FC = () => {
  const faqs = [
    {
      question: "How long until I see results?",
      answer: "SEO typically shows momentum within 3-4 months, with significant traffic growth by month 6. Website conversion improvements are often immediate once the new site is launched, as we optimize for user intent from day one."
    },
    {
      question: "What if I don't have professional photography?",
      answer: "I provide art direction and can connect you with hospitality photographers, or work with your existing visual assets to maximize their impact. High-quality imagery is non-negotiable for conversion."
    },
    {
      question: "Do you offer payment plans?",
      answer: "Yes. Every project includes flexible payment options aligned with hospitality seasonality. We understand cash flow cycles in this business better than any generic agency."
    },
    {
      question: "Will this work in my location?",
      answer: "The framework is location-agnostic but performs best in areas with strong tourist demand and competitive OTA presence. If guests are already looking for properties in your area, we can capture them."
    },
    {
      question: "What's the investment range?",
      answer: "Projects typically range from €8,000-€18,000 depending on property size and scope. Discovery calls help establish exact scope and investment needed to hit your targets."
    }
  ];

  return (
    <section className="py-32 px-6 md:px-12 bg-cream">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-4xl md:text-6xl mb-20 text-center">Frequently Asked Questions</h2>
        <div className="max-w-4xl mx-auto">
          {faqs.map((faq, i) => (
            <FAQItem key={i} {...faq} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;
