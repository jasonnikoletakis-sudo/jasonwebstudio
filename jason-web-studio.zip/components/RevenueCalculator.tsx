
import React, { useState } from 'react';
import { getRevenueAnalysis } from '../services/geminiService.ts';
import { GeminiResponse } from '../types.ts';

const RevenueCalculator: React.FC = () => {
  const [revenue, setRevenue] = useState<number>(10000);
  const [otaPct, setOtaPct] = useState<number>(80);
  const [commission, setCommission] = useState<number>(15);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<GeminiResponse | null>(null);

  const handleCalculate = async () => {
    setLoading(true);
    const analysis = await getRevenueAnalysis(revenue, otaPct, commission);
    setResult(analysis);
    setLoading(false);
  };

  return (
    <section className="py-32 bg-white">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="max-w-3xl mx-auto text-center mb-24">
          <span className="text-xs font-bold uppercase tracking-[0.4em] text-accent mb-6 block">Intelligence</span>
          <h2 className="text-4xl md:text-6xl mb-8 tracking-tight">AI Booking Potential Analysis</h2>
          <p className="text-xl text-charcoal/40 font-light">Input your current metrics and let Gemini analyze your potential savings through the Direct Booking Framework.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-px bg-charcoal/5 border border-charcoal/5 overflow-hidden shadow-2xl">
          <div className="space-y-12 bg-cream p-12 lg:p-20">
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-[0.3em] text-charcoal/40 mb-4">Avg. Monthly Revenue (€)</label>
              <input 
                type="number" 
                value={revenue} 
                onChange={(e) => setRevenue(Number(e.target.value))}
                className="w-full bg-transparent border-b border-charcoal/20 px-0 py-4 text-3xl font-light focus:outline-none focus:border-accent transition-colors"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-[0.3em] text-charcoal/40 mb-4">Current % OTA Bookings</label>
              <div className="flex items-center gap-8">
                <input 
                  type="range" min="0" max="100" 
                  value={otaPct} 
                  onChange={(e) => setOtaPct(Number(e.target.value))}
                  className="flex-grow accent-accent h-1"
                />
                <div className="text-2xl font-light w-16">{otaPct}%</div>
              </div>
            </div>
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-[0.3em] text-charcoal/40 mb-4">Avg. Commission Rate (%)</label>
              <input 
                type="number" 
                value={commission} 
                onChange={(e) => setCommission(Number(e.target.value))}
                className="w-full bg-transparent border-b border-charcoal/20 px-0 py-4 text-3xl font-light focus:outline-none focus:border-accent transition-colors"
              />
            </div>
            <button 
              onClick={handleCalculate}
              disabled={loading}
              className="w-full py-6 bg-charcoal text-cream text-[10px] font-bold uppercase tracking-[0.3em] hover:bg-accent disabled:opacity-50 transition-all"
            >
              {loading ? 'Analyzing with Gemini...' : 'Generate Potential Analysis'}
            </button>
          </div>

          <div className="flex items-center justify-center bg-white p-12 lg:p-20 relative">
            {result ? (
              <div className="w-full space-y-10 animate-in fade-in duration-1000">
                <div className="border-l-4 border-accent pl-8">
                  <div className="text-[10px] uppercase tracking-[0.3em] font-bold text-charcoal/40 mb-2">Annual Potential Savings</div>
                  <div className="text-6xl md:text-7xl font-bold tracking-tighter text-charcoal">€{result.potentialSavings.toLocaleString()}</div>
                </div>
                <div>
                  <h4 className="font-bold text-[10px] uppercase tracking-[0.3em] text-accent mb-6">Strategic Insight</h4>
                  <p className="text-lg text-charcoal/60 leading-relaxed font-light italic">"{result.analysis}"</p>
                </div>
                <div className="grid grid-cols-1 gap-4">
                  {result.strategyTips.map((tip, i) => (
                    <div key={i} className="flex gap-4 p-4 bg-cream/50 text-sm font-light text-charcoal/80 border border-charcoal/5">
                      <span className="font-bold text-accent">0{i+1}</span> {tip}
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center">
                <div className="w-20 h-20 mx-auto mb-8 bg-cream flex items-center justify-center rounded-full border border-charcoal/5">
                  <div className="w-2 h-2 bg-accent rounded-full animate-ping"></div>
                </div>
                <p className="text-charcoal/30 text-sm font-bold uppercase tracking-[0.2em] max-w-xs mx-auto">Fill in your metrics to unlock <br />revenue analysis</p>
              </div>
            )}
            <div className="absolute top-0 right-0 p-8 opacity-5">
               <span className="text-[10rem] font-bold leading-none">AI</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default RevenueCalculator;
