import React, { useState, useEffect } from 'react';

interface NavigationProps {
  onBookRealCall: () => void;
  onAuditClick: () => void;
}

const Navigation: React.FC<NavigationProps> = ({ onBookRealCall, onAuditClick }) => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-[60] transition-all duration-1000 ${isScrolled ? 'bg-white/80 backdrop-blur-2xl py-5 shadow-sm' : 'bg-transparent py-12'}`}>
      <div className="max-w-[1400px] mx-auto px-6 md:px-12 flex justify-between items-center">
        <div 
          className="text-2xl font-black tracking-tighter cursor-pointer text-charcoal flex items-center gap-2 group"
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        >
          <div className="w-8 h-8 bg-charcoal flex items-center justify-center text-cream text-xs group-hover:bg-accent transition-colors">J</div>
          <span className="hidden sm:inline">STUDIO</span>
        </div>
        
        <div className="flex space-x-12 items-center">
          <div className="hidden lg:flex items-center space-x-10">
            {['services', 'case-study', 'about'].map((item) => (
              <button
                key={item}
                onClick={() => scrollToSection(item)}
                className="text-[10px] font-bold uppercase tracking-[0.4em] text-charcoal/40 hover:text-charcoal transition-colors relative group"
              >
                {item.replace('-', ' ')}
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-accent transition-all group-hover:w-full"></span>
              </button>
            ))}
          </div>
          
          <button 
            onClick={onBookRealCall}
            className={`px-8 py-4 bg-charcoal text-cream text-[10px] font-bold uppercase tracking-[0.4em] transition-all hover:bg-accent hover:text-charcoal shadow-xl ${isScrolled ? 'scale-90' : 'scale-100'}`}
          >
            Book Call
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;