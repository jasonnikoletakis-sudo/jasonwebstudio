import React from 'react';

interface HeroProps {
  onAuditClick: () => void;
}

const Hero: React.FC<HeroProps> = ({ onAuditClick }) => {
  return (
    <section className="relative min-h-screen flex flex-col justify-center px-6 md:px-12 max-w-[1400px] mx-auto overflow-hidden">
      <div className="relative z-10 pt-20">
        <div className="inline-flex items-center gap-3 mb-12 animate-in fade-in slide-in-from-left-4 duration-1000">
           <div className="w-12 h-[1px] bg-accent"></div>
           <span className="text-[10px] uppercase tracking-[0.5em] font-bold text-accent/80">Exclusively for Boutique Hospitality</span>
        </div>
        
        <h1 className="text-huge font-extrabold text-charcoal mb-12 tracking-[-0.05em] animate-in fade-in slide-in-from-bottom-8 duration-1000">
          Reclaim Your <br />
          <span className="gold-gradient italic font-light">Independence.</span>
        </h1>
        
        <p className="text-2xl md:text-4xl text-charcoal/40 max-w-3xl mb-16 font-light leading-[1.3] tracking-tight animate-in fade-in duration-1000 delay-300">
          We build high-converting web frameworks that turn travelers into guests—directly. No commissions. No middleman.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center gap-8 animate-in fade-in duration-1000 delay-500">
          <button 
            onClick={onAuditClick}
            className="group relative w-full sm:w-auto px-16 py-8 bg-charcoal text-cream text-[11px] font-bold uppercase tracking-[0.4em] overflow-hidden transition-all hover:shadow-[0_20px_40px_-10px_rgba(26,26,26,0.3)] transform hover:-translate-y-1"
          >
            <span className="relative z-10">Get Free Market Audit</span>
            <div className="absolute inset-0 bg-accent translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
          </button>
          
          <button className="text-[10px] font-bold uppercase tracking-[0.3em] text-charcoal/40 hover:text-accent transition-colors border-b border-charcoal/10 pb-1">
            View Case Studies
          </button>
        </div>
      </div>
      
      {/* Background Accents */}
      <div className="absolute top-1/2 right-[-10%] -translate-y-1/2 w-[60%] h-[120%] bg-accent/10 -z-10 blur-[180px] rounded-full rotate-12 animate-pulse"></div>
      <div className="absolute top-[20%] left-[-5%] w-[30%] h-[40%] bg-charcoal/5 -z-10 blur-[120px] rounded-full"></div>
    </section>
  );
};

export default Hero;