
import React, { useState, useEffect } from 'react';
import { getCalConfig, saveCalConfig, CalConfig } from '../services/calService.ts';

const CalSettingsModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const [config, setConfig] = useState<CalConfig>(getCalConfig());

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    saveCalConfig(config);
    onClose();
    window.location.reload(); // Reload to apply new cal settings
  };

  return (
    <div className="fixed inset-0 z-[150] flex items-center justify-center p-4 animate-in fade-in duration-300">
      <div className="absolute inset-0 bg-charcoal/90 backdrop-blur-md" onClick={onClose}></div>
      <div className="relative w-full max-w-md bg-white p-10 shadow-2xl border border-accent/20">
        <h2 className="text-2xl font-bold mb-8 tracking-tighter">Integration Settings</h2>
        
        <form onSubmit={handleSave} className="space-y-6">
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-widest text-charcoal/40 mb-2">Cal.com API Key</label>
            <input 
              type="password"
              value={config.apiKey}
              onChange={(e) => setConfig({...config, apiKey: e.target.value})}
              placeholder="cal_live_..."
              className="w-full border-b border-charcoal/10 py-3 focus:outline-none focus:border-accent text-sm"
            />
            <p className="mt-1 text-[9px] text-charcoal/30 italic">Used to display live availability on buttons.</p>
          </div>
          
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-widest text-charcoal/40 mb-2">Cal.com Username</label>
            <input 
              type="text"
              value={config.username}
              onChange={(e) => setConfig({...config, username: e.target.value})}
              placeholder="jason-web-studio"
              className="w-full border-b border-charcoal/10 py-3 focus:outline-none focus:border-accent text-sm font-medium"
            />
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase tracking-widest text-charcoal/40 mb-2">Event Slug</label>
            <input 
              type="text"
              value={config.eventSlug}
              onChange={(e) => setConfig({...config, eventSlug: e.target.value})}
              placeholder="15min"
              className="w-full border-b border-charcoal/10 py-3 focus:outline-none focus:border-accent text-sm"
            />
          </div>

          <div className="pt-6 flex gap-4">
            <button 
              type="submit"
              className="flex-grow py-4 bg-charcoal text-cream text-[10px] font-bold uppercase tracking-widest hover:bg-accent transition-all"
            >
              Save & Link
            </button>
            <button 
              type="button"
              onClick={onClose}
              className="px-6 py-4 border border-charcoal/10 text-[10px] font-bold uppercase tracking-widest"
            >
              Cancel
            </button>
          </div>
        </form>
        
        <div className="mt-8 pt-8 border-t border-charcoal/5">
          <p className="text-[10px] text-charcoal/40 leading-relaxed">
            Linking your API key enables real-time availability displays. Your key is stored securely in your browser's local storage.
          </p>
        </div>
      </div>
    </div>
  );
};

export default CalSettingsModal;
