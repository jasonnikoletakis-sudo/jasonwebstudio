import React from 'react';

interface FooterProps {
  onBookRealCall: () => void;
  onSettingsClick: () => void;
}

const Footer: React.FC<FooterProps> = ({ onBookRealCall, onSettingsClick }) => {
  return (
    <footer className="bg-charcoal text-cream py-32 px-6 md:px-12">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-20 mb-24">
          <div className="lg:col-span-5">
            <div className="text-3xl font-bold tracking-tighter mb-10">JASON <span className="font-light text-accent">WEB STUDIO</span></div>
            <p className="text-2xl text-cream/40 font-light mb-12 max-w-md leading-relaxed">Stop paying commissions. <br /><span className="text-cream/80">Start owning your bookings.</span></p>
            <div className="space-y-6">
              <a href="mailto:jasonnikoletakis@gmail.com" className="block text-xl hover:text-accent transition-colors font-light underline decoration-accent/30 underline-offset-8">jasonnikoletakis@gmail.com</a>
              <a href="tel:6982859470" className="block text-xl hover:text-accent transition-colors font-light tracking-tight">+30 698 285 9470</a>
              <p className="text-xs font-bold uppercase tracking-[0.3em] text-cream/20">Mediterranean Headquartered. <br />Global Reach.</p>
            </div>
          </div>
          
          <div className="lg:col-span-7 grid grid-cols-2 md:grid-cols-3 gap-16">
            <div>
              <h4 className="text-[10px] font-bold uppercase tracking-[0.3em] text-accent mb-10">Navigation</h4>
              <ul className="space-y-6 text-sm font-light text-cream/60">
                <li><a href="#services" className="hover:text-white transition-colors">Strategic Services</a></li>
                <li><a href="#case-study" className="hover:text-white transition-colors">Case Studies</a></li>
                <li><a href="#about" className="hover:text-white transition-colors">Our Story</a></li>
                <li>
                  <button 
                    onClick={onBookRealCall} 
                    className="hover:text-accent transition-colors text-left uppercase tracking-[0.3em] text-[10px] font-bold"
                  >
                    Book Call
                  </button>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-[10px] font-bold uppercase tracking-[0.3em] text-accent mb-10">Resources</h4>
              <ul className="space-y-6 text-sm font-light text-cream/60">
                <li><a href="#" className="hover:text-white transition-colors">Booking Guide</a></li>
                <li><a href="#" className="hover:text-white transition-colors">SEO Framework</a></li>
                <li><a href="#" className="hover:text-white transition-colors">ROI Insights</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-[10px] font-bold uppercase tracking-[0.3em] text-accent mb-10">Legal</h4>
              <ul className="space-y-6 text-xs font-light text-cream/40">
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terms of Use</a></li>
                <li>
                  <button 
                    onClick={onSettingsClick} 
                    className="hover:text-white transition-colors uppercase tracking-[0.1em] text-[9px]"
                  >
                    Link Cal.com Key
                  </button>
                </li>
                <li className="pt-4 border-t border-white/5 font-bold uppercase tracking-widest">© {new Date().getFullYear()}</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;