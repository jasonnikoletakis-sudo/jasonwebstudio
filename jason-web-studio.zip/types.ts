
export interface CaseStudyPoint {
  title: string;
  points: string[];
}

export interface ServiceItem {
  id: string;
  title: string;
  headline: string;
  body: string;
  included: string[];
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface GeminiResponse {
  analysis: string;
  potentialSavings: number;
  strategyTips: string[];
}
