/**
 * Service to manage Cal.com integration.
 * Since Cal.com API requires an API key, we store it in localStorage for the user.
 */

export interface CalConfig {
  apiKey: string;
  username: string;
  eventSlug: string;
}

const STORAGE_KEY = 'jason_studio_cal_config';

// The API key is now empty by default to prevent GitHub Sync blocks.
// Users can add their own key via the Settings modal in the footer.
const DEFAULT_CONFIG: CalConfig = {
  apiKey: '',
  username: 'jason-nikoletakis-fb2ai0',
  eventSlug: '30min'
};

export const getCalConfig = (): CalConfig => {
  const saved = localStorage.getItem(STORAGE_KEY);
  return saved ? JSON.parse(saved) : DEFAULT_CONFIG;
};

export const saveCalConfig = (config: CalConfig) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
};

/**
 * Fetches the next available slot for the configured event.
 * Note: This requires a valid Cal.com API Key.
 */
export const fetchNextAvailableSlot = async (config: CalConfig): Promise<string | null> => {
  if (!config.apiKey || !config.username) return null;

  try {
    const now = new Date();
    const future = new Date();
    future.setDate(now.getDate() + 7);

    const response = await fetch(`https://api.cal.com/v1/availability?apiKey=${config.apiKey}&username=${config.username}&dateFrom=${now.toISOString()}&dateTo=${future.toISOString()}`);
    
    if (!response.ok) {
        console.warn("Cal.com API responded with error.");
        return "Check availability";
    }
    
    return "Slots available soon"; 
  } catch (error) {
    console.error("Cal.com API Error:", error);
    return "View schedule";
  }
};