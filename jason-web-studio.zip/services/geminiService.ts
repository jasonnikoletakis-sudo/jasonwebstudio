import { GoogleGenAI, Type } from "@google/genai";

/**
 * Calculates potential savings and provides a strategic overview of 
 * shifting from OTA dependency to direct bookings.
 */
export const getRevenueAnalysis = async (
  monthlyRevenue: number,
  otaPercentage: number,
  avgCommission: number
) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `Analyze this hospitality revenue scenario:
    - Current Monthly Revenue: €${monthlyRevenue}
    - % Bookings through OTAs (Booking.com/Airbnb): ${otaPercentage}%
    - Average Commission Paid: ${avgCommission}%
    
    Calculate the annual commission loss and provide a brief strategic analysis on how moving to 70% direct bookings would impact their business. Return JSON.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{ parts: [{ text: prompt }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            analysis: { type: Type.STRING },
            potentialSavings: { type: Type.NUMBER },
            strategyTips: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ["analysis", "potentialSavings", "strategyTips"]
        }
      }
    });

    return JSON.parse(response.text.trim());
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return null;
  }
};

/**
 * Powers the fictional AI discovery chat session with Jason's persona.
 */
export const getDiscoveryResponse = async (history: { role: 'user' | 'model', parts: { text: string }[] }[]) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: history, // Pass history directly as it follows the Content[] structure
      config: {
        systemInstruction: `You are Jason Nikoletakis, the founder of Jason Web Studio. You are conducting a "fictional" discovery call. 
        Your tone is authoritative, minimalist, and deeply empathetic to hotel owners' struggles with OTAs.
        Keep responses concise (max 3 sentences). 
        Ask one strategic question at a time about their property, occupancy, or OTA pain points.
        Maintain a high-end, luxury hospitality consultant persona.`,
      },
    });
    return response.text;
  } catch (error) {
    console.error("Discovery Error:", error);
    return "The line seems to be breaking up—hospitality is a busy business. Let's try that again. What's the biggest challenge your property faces with direct bookings?";
  }
};

/**
 * Performs a real-time digital presence audit using Google Search grounding.
 */
export const getPropertyAudit = async (propertyName: string, location: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const prompt = `Perform a high-level digital presence audit for the following hospitality property:
    Property Name: ${propertyName}
    Location: ${location}

    Focus on:
    1. Current search visibility and OTA dependency signs.
    2. Competitor landscape in that specific region.
    3. Three specific recommendations to increase direct bookings.
    
    Return the response in a structured JSON format. Use Google Search for the most up-to-date regional context.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: [{ parts: [{ text: prompt }] }],
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            overallScore: { type: Type.NUMBER, description: "A score from 1-100 on digital presence." },
            marketAnalysis: { type: Type.STRING },
            competitors: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            recommendations: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ["overallScore", "marketAnalysis", "competitors", "recommendations"]
        }
      }
    });

    return JSON.parse(response.text.trim());
  } catch (error) {
    console.error("Audit Error:", error);
    return null;
  }
};

/**
 * Service for Alex, Jason's Secretary.
 */
export const getAlexResponse = async (history: { role: 'user' | 'model', parts: { text: string }[] }[]) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: history,
      config: {
        systemInstruction: `You are Alex, the executive secretary to Jason Nikoletakis, the founder of Jason Web Studio.
        
        Your Personality:
        - Sophisticated, poised, and impeccably professional.
        - Helpful but protective of Jason's focus; you gatekeep but with absolute grace.
        - Concise. You never use three sentences when one will do.
        
        Your Knowledge:
        - Jason Nikoletakis's Studio: Focuses on Direct Booking Frameworks (Web Design + SEO) for boutique hospitality.
        - Services: Strategic Web Design (optimized for trust and direct conversion) and Hospitality SEO (dominating high-intent search).
        - Background: Jason grew up in a family villa business. He saw OTAs take 20% of his family's hard work. He built a system to take that power back.
        - Pricing: Generally starts at €8,000 for a comprehensive transformation.
        - Call to Action: If a user is interested in a consultation, direct them to use the "Book Real Call" buttons on the page.`,
      },
    });
    return response.text;
  } catch (error) {
    console.error("Alex Chatbot Error:", error);
    return "I'm afraid my connection to the studio is momentarily unstable. How may I best assist you with your property's revenue strategy today?";
  }
};