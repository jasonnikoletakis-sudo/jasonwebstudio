import React, { useState, useEffect } from 'react';
import Navigation from './components/Navigation.tsx';
import Hero from './components/Hero.tsx';
import CaseStudy from './components/CaseStudy.tsx';
import Services from './components/Services.tsx';
import RevenueCalculator from './components/RevenueCalculator.tsx';
import About from './components/About.tsx';
import FAQ from './components/FAQ.tsx';
import Footer from './components/Footer.tsx';
import CalModal from './components/CalModal.tsx';
import AuditModal from './components/AuditModal.tsx';
import CalSettingsModal from './components/CalSettingsModal.tsx';
import AlexChatbot from './components/AlexChatbot.tsx';
import { getCalConfig, fetchNextAvailableSlot } from './services/calService.ts';

const App: React.FC = () => {
  const [isCalOpen, setIsCalOpen] = useState(false);
  const [isAuditOpen, setIsAuditOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [nextSlot, setNextSlot] = useState<string | null>(null);

  useEffect(() => {
    const checkAvailability = async () => {
      const config = getCalConfig();
      if (config.apiKey) {
        const slot = await fetchNextAvailableSlot(config);
        setNextSlot(slot);
      }
    };
    checkAvailability();
  }, []);

  const openCal = () => {
    setIsAuditOpen(false);
    setIsCalOpen(true);
  };
  const closeCal = () => setIsCalOpen(false);

  const openAudit = () => {
    setIsAuditOpen(true);
  };
  const closeAudit = () => setIsAuditOpen(false);

  const openSettings = () => setIsSettingsOpen(true);
  const closeSettings = () => setIsSettingsOpen(false);

  return (
    <div className="min-h-screen selection:bg-accent selection:text-charcoal">
      <Navigation 
        onBookRealCall={openCal} 
        onAuditClick={openAudit}
      />
      
      <main>
        <Hero onAuditClick={openAudit} />
        
        <CaseStudy />
        
        <Services />
        
        <RevenueCalculator />
        
        <About />
        
        {/* Who this is for section */}
        <section className="py-32 px-6 md:px-12 bg-white">
          <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-20">
            <div>
              <h2 className="text-4xl md:text-5xl mb-12 tracking-tighter">Who this is for</h2>
              <ul className="space-y-10">
                <li className="flex gap-6">
                  <span className="w-10 h-10 bg-charcoal text-cream flex items-center justify-center shrink-0 font-bold text-xs">01</span>
                  <div>
                    <h4 className="font-bold text-lg mb-2 text-charcoal">Boutique Hotels (8-30 rooms)</h4>
                    <p className="text-charcoal/60 font-light">Small enough to be agile, large enough to feel the sting of 20% OTA commissions.</p>
                  </div>
                </li>
                <li className="flex gap-6">
                  <span className="w-10 h-10 bg-charcoal text-cream flex items-center justify-center shrink-0 font-bold text-xs">02</span>
                  <div>
                    <h4 className="font-bold text-lg mb-2 text-charcoal">Luxury Villas & Holiday Rentals</h4>
                    <p className="text-charcoal/60 font-light">Exclusive properties that require high-touch visual storytelling to justify premium rates.</p>
                  </div>
                </li>
                <li className="flex gap-6">
                  <span className="w-10 h-10 bg-charcoal text-cream flex items-center justify-center shrink-0 font-bold text-xs">03</span>
                  <div>
                    <h4 className="font-bold text-lg mb-2 text-charcoal">Independent-Minded Owners</h4>
                    <p className="text-charcoal/60 font-light">Property managers ready to invest in long-term revenue strategy rather than short-term fixes.</p>
                  </div>
                </li>
              </ul>
            </div>
            
            <div className="bg-cream p-12 lg:p-20 border border-charcoal/5 relative overflow-hidden group">
              <h2 className="text-4xl mb-12 text-charcoal tracking-tighter relative z-10">Not for you if...</h2>
              <ul className="space-y-8 text-lg font-light text-charcoal/80 italic relative z-10">
                <li className="flex items-center gap-4"><span className="w-1.5 h-1.5 bg-accent rounded-full"></span> You're happy with your current OTA dependency.</li>
                <li className="flex items-center gap-4"><span className="w-1.5 h-1.5 bg-accent rounded-full"></span> You need instant results (this is a 6-12 month strategy).</li>
                <li className="flex items-center gap-4"><span className="w-1.5 h-1.5 bg-accent rounded-full"></span> You're not willing to invest in quality design and SEO.</li>
              </ul>
              <div className="absolute top-0 right-0 p-8 opacity-[0.03] text-[12rem] font-bold leading-none pointer-events-none group-hover:opacity-[0.05] transition-opacity">NO</div>
            </div>
          </div>
        </section>

        {/* Final CTA */}
        <section id="cta" className="py-40 px-6 md:px-12 bg-charcoal text-cream text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-accent/5 -z-10 blur-[150px]"></div>
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl md:text-8xl mb-12 leading-tight tracking-tighter">Take Back Control.</h2>
            <p className="text-xl md:text-2xl text-cream/40 font-light mb-16 leading-relaxed max-w-2xl mx-auto">
              Let's talk about your property, your current booking split, and how The Direct Booking Framework can work for you.
            </p>
            
            <div className="flex flex-col sm:flex-row justify-center gap-6 mb-16">
              <button 
                onClick={openCal}
                className="px-12 py-8 bg-accent text-charcoal text-[10px] font-bold uppercase tracking-[0.4em] hover:bg-white transition-all shadow-2xl transform hover:-translate-y-1"
              >
                Book Real Consultation
                {nextSlot && <span className="block mt-2 text-[8px] opacity-60">Next available: {nextSlot}</span>}
              </button>
            </div>
          </div>
        </section>
        
        <FAQ />
      </main>
      
      <Footer onBookRealCall={openCal} onSettingsClick={openSettings} />
      
      <CalModal 
        isOpen={isCalOpen} 
        onClose={closeCal} 
      />

      <AuditModal 
        isOpen={isAuditOpen} 
        onClose={closeAudit} 
      />

      <CalSettingsModal 
        isOpen={isSettingsOpen} 
        onClose={closeSettings} 
      />

      {/* Persistent AI Secretary Assistant */}
      <AlexChatbot />
    </div>
  );
};

export default App;